
import unittest
from datetime import datetime, timezone

from tillpoint import db, reports
from tillpoint.api import App
from tillpoint.catalog import OutOfStock


class OrderDeskTest(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect()
        self.app = App(self.conn)
        self.app.catalog.add_product("MUG", "Mug", 1200, stock=10)
        self.app.catalog.add_product("TEE", "T-shirt", 2500, stock=3)
        self.conn.execute(
            "INSERT INTO coupons (code, kind, value) VALUES ('TEN', 'percent', 10)"
        )

    def test_order_totals_with_tax(self):
        order = self.app.orders.create(
            "ana", [("MUG", 2), ("TEE", 1)], region="CA"
        )
        self.assertEqual(order["subtotal_cents"], 4900)
        self.assertEqual(order["tax_cents"], 355)
        self.assertEqual(order["total_cents"], 5255)
        self.assertEqual(self.app.catalog.get_product("MUG").stock, 8)

    def test_coupon_takes_ten_percent(self):
        order = self.app.orders.create(
            "ana", [("MUG", 1)], coupon_code="TEN"
        )
        self.assertEqual(order["discount_cents"], 120)
        self.assertEqual(order["total_cents"], 1080)

    def test_out_of_stock(self):
        with self.assertRaises(OutOfStock):
            self.app.orders.create("ana", [("TEE", 4)])
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_payment_marks_order_paid(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        status, payload = self.app.handle(
            "POST",
            "/webhooks/payments",
            {
                "id": "evt_1",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": 1200
            }
        )
        self.assertEqual((status, payload["status"]), (200, "paid"))

    def test_cancel_paid_order_restocks(self):
        order = self.app.orders.create("ana", [("TEE", 2)])
        self.app.payments.handle_event(
            {
                "id": "evt_2",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": 5000
            }
        )
        self.app.orders.cancel(order["id"])
        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_daily_sales(self):
        order = self.app.orders.create("ana", [("MUG", 1)])
        noon = datetime(2025, 3, 10, 12, 0, tzinfo=timezone.utc)
        self.app.payments.handle_event(
            {
                "id": "evt_3",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": 1200
            },
            now=noon
        )
        self.assertEqual(
            reports.daily_sales(self.conn, "2025-03-10"),
            {
                "day": "2025-03-10",
                "revenue_cents": 1200,
                "orders": 1
            }
        )

    def test_duplicate_webhook_does_not_duplicate_payment(self):
        order = self.app.orders.create("ana", [("MUG", 1)])

        event = {
            "id": "evt_duplicate",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": order["total_cents"]
        }

        self.app.payments.handle_event(event)
        self.app.payments.handle_event(event)

        self.assertEqual(
            self.app.payments.paid_cents(order["id"]),
            order["total_cents"]
        )

        count = self.conn.execute(
            "SELECT COUNT(*) FROM payments WHERE event_id = ?",
            ("evt_duplicate",)
        ).fetchone()[0]

        self.assertEqual(count, 1)

    def test_price_change(self):
        self.app.handle("PUT", "/products/MUG", {"price_cents": 1500})
        self.assertEqual(
            self.app.catalog.get_product("MUG").price_cents, 1500
        )

    def test_cancel_pending_order_restores_stock(self):
        order = self.app.orders.create("ana", [("TEE", 2)])

        self.assertEqual(self.app.catalog.get_product("TEE").stock, 1)

        self.app.orders.cancel(order["id"])

        self.assertEqual(self.app.catalog.get_product("TEE").stock, 3)

    def test_coupon_discount_is_applied_before_tax(self):
        order = self.app.orders.create(
            "ana",
            [("MUG", 1)],
            region="CA",
            coupon_code="TEN"
        )

        self.assertEqual(order["subtotal_cents"], 1200)
        self.assertEqual(order["discount_cents"], 120)
        self.assertEqual(order["tax_cents"], 78)
        self.assertEqual(order["total_cents"], 1158)

    def test_daily_sales_uses_india_timezone(self):
        order = self.app.orders.create("ana", [("MUG", 1)])

        payment_time = datetime(
            2025, 3, 9, 20, 0, tzinfo=timezone.utc
        )

        self.app.payments.handle_event(
            {
                "id": "evt_india",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": 1200,
            },
            now=payment_time,
        )

        result = reports.daily_sales(
            self.conn,
            "2025-03-10",
            utc_offset_minutes=330,
        )

        self.assertEqual(
            result,
            {
                "day": "2025-03-10",
                "revenue_cents": 1200,
                "orders": 1,
            },
        )

    def test_concurrent_stock_change_does_not_allow_negative_stock(self):
        self.app.catalog.get_product("TEE")

        self.conn.execute(
            "UPDATE products SET stock = 0 WHERE sku = 'TEE'"
        )

        with self.assertRaises(OutOfStock):
            self.app.catalog.reserve("TEE", 1)

        stock = self.conn.execute(
            "SELECT stock FROM products WHERE sku = 'TEE'"
        ).fetchone()["stock"]

        self.assertEqual(stock, 0)

    def test_separate_second_payment_marks_order_overpaid(self):
        order = self.app.orders.create("ana", [("MUG", 1)])

        first_payment = {
            "id": "evt_first",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": order["total_cents"],
        }

        second_payment = {
            "id": "evt_second",
            "type": "payment.succeeded",
            "order_id": order["id"],
            "amount_cents": order["total_cents"],
        }

        self.app.payments.handle_event(first_payment)
        result = self.app.payments.handle_event(second_payment)

        self.assertEqual(result, "overpaid")

        self.assertEqual(
            self.app.payments.paid_cents(order["id"]),
            order["total_cents"] * 2,
        )

        status = self.conn.execute(
            "SELECT status FROM orders WHERE id = ?",
            (order["id"],),
        ).fetchone()["status"]

        self.assertEqual(status, "overpaid")

        count = self.conn.execute(
            "SELECT COUNT(*) FROM payments WHERE order_id = ?",
            (order["id"],),
        ).fetchone()[0]

        self.assertEqual(count, 2)

    def test_cancel_overpaid_order_restores_stock(self):
        order = self.app.orders.create("ana", [("TEE", 2)])

        self.app.payments.handle_event(
            {
                "id": "evt_overpaid_first",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": order["total_cents"],
            }
        )

        self.app.payments.handle_event(
            {
                "id": "evt_overpaid_second",
                "type": "payment.succeeded",
                "order_id": order["id"],
                "amount_cents": order["total_cents"],
            }
        )

        self.app.orders.cancel(order["id"])

        self.assertEqual(
            self.app.catalog.get_product("TEE").stock,
            3,
        )


if __name__ == "__main__":
    unittest.main()
